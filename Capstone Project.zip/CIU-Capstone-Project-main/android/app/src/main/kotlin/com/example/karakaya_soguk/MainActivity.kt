package com.example.karakaya_soguk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
