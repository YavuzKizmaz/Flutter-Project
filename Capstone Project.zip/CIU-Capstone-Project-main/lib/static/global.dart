import 'package:flutter/material.dart';

class Global {
  static var mavi = Colors.blue;
  static String font = "Roboto";
  static String sipno = "";
  static String tahsno = "T";
  static String duzenlesipno = "";
  static String duzenletahsno = "";
  static String carikod = "";
  static String cariunvan = "";
  static String sunucu = "";
  static String sqlsa = "";
  static String sqlpass = "";
  static String sirket = "";
  static String kuladi = "";
  static String pass = "";
  static String name = "";
  static String rutkodu = "";
  static int mesaj = 0;
  static bool acik = false;
}
